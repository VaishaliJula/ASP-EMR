 export class PatientModel {
    firstName : String;
    lastName : String;
    gender : String;
    mobileNo : Number;
}